/* CS4-53203: Systems Programming \
/* Name: Garrett Stallsmith \
/* Date: 01/22/2024 \
/* AssignmentWarmup.txt\
*/

#include <stdio.h>

int main() {
    printf("Welcome to CS43203 - Systems Programming.\n");
    return 0;
}