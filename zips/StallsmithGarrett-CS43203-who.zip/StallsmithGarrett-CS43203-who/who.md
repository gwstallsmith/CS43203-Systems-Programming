Deliverable
---

```
Code: who.c
Executable: Who.out
Usage: ./Who.out
       or
       ./Who.out whoami
       or
       ./Who.out who am i
```
```
'whoami' argument only displays the argument 'whoami' and the user's name
```
```
'who am i' argument displays arguments along with user name, terminal, and time of login
```